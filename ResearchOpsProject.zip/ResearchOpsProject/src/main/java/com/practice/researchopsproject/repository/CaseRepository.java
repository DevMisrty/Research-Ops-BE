package com.practice.researchopsproject.repository;

import com.practice.researchopsproject.entity.Case;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface CaseRepository extends MongoRepository<Case, String> {
    Case findByCaseId(String caseId);
}

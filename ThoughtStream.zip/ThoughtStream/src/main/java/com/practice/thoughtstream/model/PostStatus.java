package com.practice.thoughtstream.model;

public enum PostStatus {
    DRAFT,
    PUBLISHED,
    REJECTED
}

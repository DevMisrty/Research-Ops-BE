package com.Assignment.Multi_Vendor.Food.Delivery.service;


import com.Assignment.Multi_Vendor.Food.Delivery.model.DeliveryAgent;
import com.Assignment.Multi_Vendor.Food.Delivery.model.Orders;
import java.util.*;

public interface DeliveryAgentService {

    List<DeliveryAgent> getAllDeliveryAgents();

    List<DeliveryAgent> getAllDeliveryAgents(Date before);
}

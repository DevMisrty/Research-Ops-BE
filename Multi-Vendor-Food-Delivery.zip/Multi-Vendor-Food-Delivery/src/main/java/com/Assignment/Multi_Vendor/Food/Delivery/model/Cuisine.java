package com.Assignment.Multi_Vendor.Food.Delivery.model;

public enum Cuisine {
    INDIAN,
    ITALIAN,
    CHINESE,
    MEXICAN,
    JAPANESE,
    FRENCH,
    AMERICAN,
    THAI
}

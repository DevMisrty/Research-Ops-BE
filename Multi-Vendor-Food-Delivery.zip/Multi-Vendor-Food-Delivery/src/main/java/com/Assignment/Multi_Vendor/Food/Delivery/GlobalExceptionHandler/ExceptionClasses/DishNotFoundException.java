package com.Assignment.Multi_Vendor.Food.Delivery.GlobalExceptionHandler.ExceptionClasses;

public class DishNotFoundException extends Exception{

    public DishNotFoundException(String message) {
        super(message);
    }
}

package com.practice.researchopsproject.entity;

public enum Role {
    ADMIN,
    CASE_MANAGER,
    RESEARCHER
}

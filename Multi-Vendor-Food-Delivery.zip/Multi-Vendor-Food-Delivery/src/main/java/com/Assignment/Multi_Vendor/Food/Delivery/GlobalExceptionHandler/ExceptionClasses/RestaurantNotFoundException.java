package com.Assignment.Multi_Vendor.Food.Delivery.GlobalExceptionHandler.ExceptionClasses;


public class RestaurantNotFoundException extends Exception {

    public RestaurantNotFoundException(String s) {
    }
}

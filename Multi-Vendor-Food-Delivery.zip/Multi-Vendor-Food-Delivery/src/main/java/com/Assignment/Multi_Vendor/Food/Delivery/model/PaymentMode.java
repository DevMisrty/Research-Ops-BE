package com.Assignment.Multi_Vendor.Food.Delivery.model;

import jakarta.persistence.Entity;
import lombok.Getter;
import lombok.Setter;


public enum PaymentMode {

    ONLINE,
    CASH_ON_DELIVERY
}
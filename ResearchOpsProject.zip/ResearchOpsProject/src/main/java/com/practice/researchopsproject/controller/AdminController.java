package com.practice.researchopsproject.controller;

import com.practice.researchopsproject.dto.PaginationResponseDto;
import com.practice.researchopsproject.dto.request.CreateResearcherRequestDto;
import com.practice.researchopsproject.dto.request.CreateUserRequestDto;
import com.practice.researchopsproject.dto.response.CaseManagerResponseDto;
import com.practice.researchopsproject.dto.response.ResearcherResponseDto;
import com.practice.researchopsproject.dto.response.UserResponseDto;
import com.practice.researchopsproject.entity.Role;
import com.practice.researchopsproject.services.InvitationService;
import com.practice.researchopsproject.services.UsersService;
import com.practice.researchopsproject.utilities.ApiResponse;
import com.practice.researchopsproject.utilities.Messages;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;


@Slf4j
@RestController
@RequestMapping("/api/admin")
@RequiredArgsConstructor
@CrossOrigin(originPatterns = {"localhost:3000", "localhost:5173"})
public class AdminController {

    private final UsersService usersService;
    private final InvitationService invitationService;


    @GetMapping("/casemanager")
    public ResponseEntity<ApiResponse<PaginationResponseDto<CaseManagerResponseDto>>> getListOfUsers(
            @RequestParam(required = false, defaultValue = "1") Integer page,
            @RequestParam(required = false, defaultValue = "10") Integer limit,
            @RequestParam(required = false, defaultValue = "name") String sortBy ,
            @RequestParam(required = false, defaultValue = "ASC") String direction
            ){

        if(page < 0 )page =1;
        if(limit <= 0)limit =10;

        PaginationResponseDto<CaseManagerResponseDto> response =
                usersService.getListOfCaseManager(page, limit, sortBy, direction);

        return ApiResponse.getResponse(HttpStatus.OK, Messages.LIST_OF_CASEMANAGER_FETCHED, response);
    }

    //access by admin, as well as Case Manager.
    @GetMapping("/researcher")
    public ResponseEntity<?> getListOfResearchers(
            @RequestParam(required = false, defaultValue = "1") Integer page,
            @RequestParam(required = false, defaultValue = "10") Integer limit,
            @RequestParam(required = false, defaultValue = "name") String sortBy ,
            @RequestParam(required = false, defaultValue = "ASC") String direction){
        if(page < 0)page =1;
        if(limit <= 0)limit =0;

        PaginationResponseDto<ResearcherResponseDto> response =
                usersService.getListofResearcher(page, limit, sortBy, direction);

        return ApiResponse.getResponse(HttpStatus.OK, Messages.LIST_OF_RESEARCHER_FETCHED, response);

    }

    @GetMapping("/casemanager/{search}")
    public ResponseEntity<?> getCaseManagerByName(
            @PathVariable String search,
            @RequestParam(required = false, defaultValue = "1") Integer page,
            @RequestParam(required = false, defaultValue = "10") Integer limit){

        if(page < 0)page =1;
        if(limit <= 0)limit =10;

        PaginationResponseDto<CaseManagerResponseDto> response =
                usersService.getListOfUsersByNameOrEmail(search, page, limit);

        return ApiResponse.getResponse(HttpStatus.OK, Messages.LIST_OF_CASEMANAGER_FETCHED, response);
    }

    @GetMapping("/researcher/{search}")
    public ResponseEntity<?> getResearcherByNameOrEmail(
            @PathVariable String search,
            @RequestParam(required = false, defaultValue = "1") Integer page,
            @RequestParam(required = false, defaultValue = "10") Integer limit
    ){
        if(page < 0)page =1;
        if(limit <= 0)limit =10;

        PaginationResponseDto<ResearcherResponseDto> response
                = usersService.getListOfResearcherByNameOrEmail(search, page, limit);

        return ApiResponse.getResponse(HttpStatus.OK, Messages.LIST_OF_RESEARCHER_FETCHED, response);
    }


    //  currently sending the response, and mail, which contains only the TokenId, once the
    // react app is build change the data, to the correct route according to the react router.
    //
    @PostMapping("/create/casemanager")
    public ResponseEntity<?> createCaseManager( @RequestBody CreateUserRequestDto requestDto){

        log.info("CREATING THE INVITATION ENTITY FOR, {}",requestDto );

        UUID token = invitationService.createAndSaveInvitation(requestDto);
        log.info("Token generated for request, {}", token);

        return ApiResponse.getResponse(HttpStatus.OK, Messages.MAIL_SEND, token);
    }

    @PostMapping("/create/researcher")
    public ResponseEntity<?> createResearcher(@Valid @RequestBody CreateResearcherRequestDto requestDto){

        log.info("CREATING THE INVITATION ENTITY FOR, {}",requestDto );
        UUID token = invitationService.createAndSaveInvitationForRes(requestDto);
        log.info("Token generated for request, {}", token   );

        return ApiResponse.getResponse(HttpStatus.OK, Messages.MAIL_SEND, token);
    }


    @PostMapping("/active/{id}")
    public ResponseEntity<?> activateUserProfile(@PathVariable String id){

        UserResponseDto response = usersService.activateUserProfile(id);
        return ApiResponse.getResponse(HttpStatus.ACCEPTED, Messages.PROFILE_SET_NOACTIVE, response);
    }

    @PostMapping("/deactivate/{id}")
    public ResponseEntity<?> deactivateUserProfile(@PathVariable String id){

        UserResponseDto response = usersService.deactivateUserProfile(id);
        return ApiResponse.getResponse(HttpStatus.ACCEPTED, Messages.PROFILE_SET_ACTIVE, response);
    }
}

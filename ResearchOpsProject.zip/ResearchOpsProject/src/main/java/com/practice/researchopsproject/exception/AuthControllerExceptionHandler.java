package com.practice.researchopsproject.exception;

import com.practice.researchopsproject.utilities.ExceptionResponse;
import com.practice.researchopsproject.utilities.Messages;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import javax.naming.AuthenticationException;

@RestControllerAdvice
@RequiredArgsConstructor
public class AuthControllerExceptionHandler {

    @ExceptionHandler(AuthenticationException.class)
    private ResponseEntity<ExceptionResponse> handleAuthenticationException(HttpServletRequest request){
        String url = request.getRequestURI();
        return ExceptionResponse.exceptionResponse(url, Messages.INVALID_EXCEPTION, HttpStatus.UNAUTHORIZED);
    }

    @ExceptionHandler(UsernameNotFoundException.class)
    private ResponseEntity<?> handleUsernameNotFoundException(HttpServletRequest request){
        return ExceptionResponse.exceptionResponse(
                request.getRequestURI(),
                Messages.USER_NOT_FOUND,
                HttpStatus.NOT_FOUND
        );
    }

    @ExceptionHandler(Exception.class)
    private ResponseEntity<?> handleException(HttpServletRequest request){
        return ExceptionResponse.exceptionResponse(
                request.getRequestURI(),
                "Some Exception occured.",
                HttpStatus.BAD_REQUEST
        );
    }

}

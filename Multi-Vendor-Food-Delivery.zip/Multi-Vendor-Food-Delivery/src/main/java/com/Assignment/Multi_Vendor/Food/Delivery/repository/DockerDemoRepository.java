package com.Assignment.Multi_Vendor.Food.Delivery.repository;

import com.Assignment.Multi_Vendor.Food.Delivery.model.DockerDemo;
import org.springframework.data.repository.ListCrudRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;

@Repository
public interface DockerDemoRepository extends ListCrudRepository<DockerDemo , UUID> {
    Optional<DockerDemo> findByUsername(String username);
}

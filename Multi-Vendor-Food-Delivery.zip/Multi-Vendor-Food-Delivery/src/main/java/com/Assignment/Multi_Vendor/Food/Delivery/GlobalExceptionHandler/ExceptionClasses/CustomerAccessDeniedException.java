package com.Assignment.Multi_Vendor.Food.Delivery.GlobalExceptionHandler.ExceptionClasses;

public class CustomerAccessDeniedException extends Exception {
    public CustomerAccessDeniedException(String s) {
        super(s);
    }
}

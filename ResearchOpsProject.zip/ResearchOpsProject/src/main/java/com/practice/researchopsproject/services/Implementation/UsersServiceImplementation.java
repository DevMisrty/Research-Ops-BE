package com.practice.researchopsproject.services.Implementation;

import com.practice.researchopsproject.dto.PaginationResponseDto;
import com.practice.researchopsproject.dto.UserDto;
import com.practice.researchopsproject.dto.request.UserRequestDto;
import com.practice.researchopsproject.dto.response.CaseManagerResponseDto;
import com.practice.researchopsproject.dto.response.ResearcherResponseDto;
import com.practice.researchopsproject.dto.response.UserResponseDto;
import com.practice.researchopsproject.entity.CaseManagerProfile;
import com.practice.researchopsproject.entity.ResearcherProfile;
import com.practice.researchopsproject.entity.Role;
import com.practice.researchopsproject.entity.Users;
import com.practice.researchopsproject.repository.CaseManagerProfileRepository;
import com.practice.researchopsproject.repository.ResearcherProfileRepository;
import com.practice.researchopsproject.repository.UsersRepository;
import com.practice.researchopsproject.services.UsersService;
import com.practice.researchopsproject.utilities.Mappers;
import com.practice.researchopsproject.utilities.Messages;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;


@Component
@RequiredArgsConstructor
@Slf4j
public class UsersServiceImplementation implements UsersService {

    private final UsersRepository repo;
    private final CaseManagerProfileRepository caseRepo;
    private final ResearcherProfileRepository resRepo;
    private final ModelMapper mapper;
    private final PasswordEncoder encoder;

    //role must be admin
    @Override
    public UserResponseDto saveUsers(UserRequestDto requestDto) {

        UserResponseDto response =null;

        try{
            Users users = mapper.map(requestDto, Users.class);
            users.setRole(Role.ADMIN);
            users.setPassword(encoder.encode(users.getPassword()));
            log.info("Users info, {} ", users);
            users.setActive(true);

            Users savedUser = repo.save(users);

            log.info("Saved User is, {}", savedUser);
            response = mapper.map(savedUser, UserResponseDto.class);
            log.info("Map changed , {}", response);
        }catch (Exception e){
            log.error(e.getMessage());
        }

        return response;
    }

    @Override
    public Users saveUsers(Users users) {
         return repo.save(users);
    }

    @Override
    public UserDto getUserByEmail(String email) {
        Users users = repo.findByEmail(email)
                .orElseThrow(() -> new UsernameNotFoundException(Messages.USER_NOT_FOUND));
        return mapper.map(users, UserDto.class);
    }

    // for case manager
    @Override
    public PaginationResponseDto<CaseManagerResponseDto> getListOfCaseManager(Integer page, Integer limit, String sortBy, String direction) {

        Sort sort = null;

        if(direction.equalsIgnoreCase("ASC")){
            sort = Sort.by(sortBy).ascending();
        }else {
            sort = Sort.by(sortBy).descending();
        }

        PageRequest pageRequest = PageRequest.of(page, limit, sort);

        Page<CaseManagerProfile> all = caseRepo.findAll(pageRequest);
        Page<CaseManagerResponseDto> responseDtos = all.map( profile -> Mappers.mapCaseManagerToCaseManagerResponseDto(profile));

        PaginationResponseDto<CaseManagerResponseDto> response =
                PaginationResponseDto.buildPaginatedResponse(responseDtos);

        return response;
    }

    @Override
    public PaginationResponseDto<ResearcherResponseDto> getListofResearcher(Integer page, Integer limit, String sortBy, String direction) {
        Sort sort = null;

        if(direction.equalsIgnoreCase("ASC")){
            sort = Sort.by(sortBy).ascending();
        }else {
            sort = Sort.by(sortBy).descending();
        }

        PageRequest pageRequest = PageRequest.of(page, limit, sort);
        Page<ResearcherProfile> all = resRepo.findAll(pageRequest);
        Page<ResearcherResponseDto> responseDtos = all
                .map( profile -> Mappers.mapResearcherToResearcherResponseDto(profile) );

        PaginationResponseDto<ResearcherResponseDto> response =
                PaginationResponseDto.buildPaginatedResponse(responseDtos);
        return response;
    }

    @Override
    public PaginationResponseDto<CaseManagerResponseDto> getListOfUsersByNameOrEmail(String search, Integer page, Integer limit) {
        PageRequest pageRequest = PageRequest.of(page, limit);

        Page<Users> all =
                repo.searchByNameOrEmailAndRole(search, Role.CASE_MANAGER , pageRequest);

        Page<CaseManagerResponseDto> responseDtos =
                all.map( users-> {
                    CaseManagerProfile caseManager = caseRepo.findByUser_Id(users.getId());
                    return CaseManagerResponseDto.builder()
                            .name(caseManager.getUser().getName())
                            .email(caseManager.getUser().getEmail())
                            .isActive(caseManager.getUser().isActive())
                            .assignCases(caseManager.getAssignCaseId().size())
                            .lastLogin(caseManager.getUser().getLastLogin())
                            .build();
                });
        return PaginationResponseDto.buildPaginatedResponse(responseDtos);
    }

    @Override
    public PaginationResponseDto<ResearcherResponseDto> getListOfResearcherByNameOrEmail(String search, Integer page, Integer limit) {
        PageRequest pageRequest = PageRequest.of(page, limit);

        Page<Users> all = repo.searchByNameOrEmailAndRole(search, Role.RESEARCHER, pageRequest);
        
        Page<ResearcherResponseDto> responseDtos = 
                all.map( users -> {
                    ResearcherProfile res = resRepo.findByUser_Id(users.getId());
                    return ResearcherResponseDto.builder()
                            .name(res.getUser().getName())
                            .email(res.getUser().getEmail())
                            .assignCases(res.getAssignCaseIds().size())
                            .experience(res.getExperience())
                            .isActive(res.getUser().isActive())
                            .build();
                });
        return PaginationResponseDto.buildPaginatedResponse(responseDtos);
    }

    @Override
    public UserResponseDto activateUserProfile(String id) {

        Users users = repo.findById(id)
                .orElseThrow(() -> new UsernameNotFoundException(Messages.USER_NOT_FOUND));

        if(users.isActive())return mapper.map(users, UserResponseDto.class);

        users.setActive(true);
        Users savedusers = repo.save(users);
        UserResponseDto response = mapper.map(users, UserResponseDto.class);
        return response;

    }

    @Override
    public UserResponseDto deactivateUserProfile(String id) {
        Users users = repo.findById(id)
                .orElseThrow(() -> new UsernameNotFoundException(Messages.USER_NOT_FOUND));

        if(!users.isActive())return mapper.map(users, UserResponseDto.class);

        users.setActive(false);
        Users savedUser = repo.save(users);
        UserResponseDto response = mapper.map(savedUser, UserResponseDto.class);
        return response;
    }

    @Override
    public boolean checkProfileIsActive(String email) {

        Users users = repo.findByEmail(email)
                .orElseThrow(()-> new UsernameNotFoundException(Messages.USER_NOT_FOUND));

        return users.isActive();

    }


}

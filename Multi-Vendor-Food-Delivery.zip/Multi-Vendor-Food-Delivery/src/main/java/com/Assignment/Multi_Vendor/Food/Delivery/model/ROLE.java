package com.Assignment.Multi_Vendor.Food.Delivery.model;

public enum ROLE {

    ADMIN,
    RESTAURANT_OWNER,
    CUSTOMER
}

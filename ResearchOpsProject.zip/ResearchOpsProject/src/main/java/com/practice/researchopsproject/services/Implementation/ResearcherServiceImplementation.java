package com.practice.researchopsproject.services.Implementation;

import com.practice.researchopsproject.dto.request.RegisterResearcherRequestDto;
import com.practice.researchopsproject.entity.Invitation;
import com.practice.researchopsproject.entity.InvitationStatus;
import com.practice.researchopsproject.entity.ResearcherProfile;
import com.practice.researchopsproject.entity.Users;
import com.practice.researchopsproject.repository.ResearcherProfileRepository;
import com.practice.researchopsproject.services.InvitationService;
import com.practice.researchopsproject.services.ResearcherService;
import com.practice.researchopsproject.services.UsersService;
import com.practice.researchopsproject.utilities.Messages;
import io.jsonwebtoken.security.Message;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.coyote.BadRequestException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;

@Slf4j
@Component
@RequiredArgsConstructor
public class ResearcherServiceImplementation implements ResearcherService {

    private final InvitationService invitationService;
    private final ResearcherProfileRepository repo;
    private final UsersService usersService;
    private final PasswordEncoder encoder;


    @Override
    public void createResearchProfile(String token, RegisterResearcherRequestDto requestDto) throws BadRequestException {

        Invitation invitation = invitationService.getInvitationFromToken(token);
        boolean isExpire = invitation.getExpiresIn().before(new Date());

        if(invitation.getStatus().equals(InvitationStatus.EXPIRE) || isExpire){
            throw new BadRequestException(Messages.TOKEN_EXPIRE);
        }

        Users users = Users.builder()
                .email(invitation.getEmail())
                .password(encoder.encode(requestDto.getPassword()))
                .name(invitation.getName())
                .role(invitation.getRole())
                .lastLogin(LocalDateTime.now())
                .isActive(true)
                .address(invitation.getAddress())
                .state(invitation.getState())
                .city(invitation.getCity())
                .zip(invitation.getZip()).build();

        ResearcherProfile profile = ResearcherProfile.builder()
                .experience(invitation.getExperience()).assignCaseIds(new ArrayList<>())
                .build();

        log.info("Before saving the Researcher data");
        try{

            Users savedUser = usersService.saveUsers(users);

            log.info("Users Saved, {}", savedUser);

            profile.setUser(savedUser);
            ResearcherProfile save = repo.save(profile);

            log.info("Researcher Profile saved, {}", save);


            invitationService.changeStatus(invitation, InvitationStatus.EXPIRE);


        }catch(Exception e){
            log.error(e.getMessage());
        }

    }
}

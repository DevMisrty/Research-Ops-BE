package com.practice.researchopsproject.dto.request;

public class InvitationRequestDto {
}

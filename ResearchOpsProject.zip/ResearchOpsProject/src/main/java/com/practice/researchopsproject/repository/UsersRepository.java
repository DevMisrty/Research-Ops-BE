package com.practice.researchopsproject.repository;

import com.practice.researchopsproject.entity.Role;
import com.practice.researchopsproject.entity.Users;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import java.util.Optional;

public interface UsersRepository extends MongoRepository<Users, String> {
    Optional<Users> findByEmail(String email);

    Page<Users> findAllByNameContainingIgnoreCaseOrEmailContainingIgnoreCase(String search, PageRequest pageRequest);

    @Query("""
{
  "$and": [
    { "role": ?1 },
    {
      "$or": [
        { "name": { "$regex": ?0, "$options": "i" } },
        { "email": { "$regex": ?0, "$options": "i" } }
      ]
    }
  ]
}
""")
    Page<Users> searchByNameOrEmailAndRole(
            String search,
            Role role,
            Pageable pageable
    );

    Page<Users> findAllByNameContainingIgnoreCaseOrEmailContainingIgnoreCaseAndRole(String name, Role role, PageRequest pageRequest);
}

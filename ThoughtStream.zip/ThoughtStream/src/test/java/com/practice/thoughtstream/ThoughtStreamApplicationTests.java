package com.practice.thoughtstream;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThoughtStreamApplicationTests {

    @Test
    void contextLoads() {
    }

}

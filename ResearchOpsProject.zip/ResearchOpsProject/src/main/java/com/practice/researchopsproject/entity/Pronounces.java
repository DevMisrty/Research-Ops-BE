package com.practice.researchopsproject.entity;

public enum Pronounces {

    Mr,
    Mrs,
    Miss,
    Ms

}

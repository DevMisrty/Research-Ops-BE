package com.practice.researchopsproject.entity;

public enum CaseStage {

    WORKING,
    REVIEW,
    COMPLETED

}

package com.practice.researchopsproject.services;

import com.practice.researchopsproject.dto.request.RegisterResearcherRequestDto;
import org.apache.coyote.BadRequestException;

public interface ResearcherService {
    void createResearchProfile(String token, RegisterResearcherRequestDto requestDto) throws BadRequestException;
}

package com.learning.expensetrackermdb.exception.customexception;

public class IncorrectInputValueException extends Exception {
    public IncorrectInputValueException(String message) {
        super(message);
    }
}

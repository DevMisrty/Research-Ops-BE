package com.Assignment.Multi_Vendor.Food.Delivery.GlobalExceptionHandler.ExceptionClasses;


public class UserNameNotFoundException extends Exception{
    public UserNameNotFoundException() {
        super("");
    }
}

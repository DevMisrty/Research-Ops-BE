package com.Assignment.Multi_Vendor.Food.Delivery.controller;

import com.Assignment.Multi_Vendor.Food.Delivery.model.DockerDemo;
import com.Assignment.Multi_Vendor.Food.Delivery.repository.DockerDemoRepository;
import com.Assignment.Multi_Vendor.Food.Delivery.utility.MessageConstants;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/menu/docker")
@RequiredArgsConstructor
public class DockerDemoControlller {

    private final DockerDemoRepository repo;

    @GetMapping("/get/{username}")
    public DockerDemo getDockerDemo(@PathVariable String username){
        return repo.findByUsername(username).orElseThrow(()-> new RuntimeException(MessageConstants.NOT_FOUND));
    }

    @PostMapping("/save")
    public DockerDemo saveDockerDemo(@RequestBody DockerDemo demo){
        return repo.save(demo);
    }
}

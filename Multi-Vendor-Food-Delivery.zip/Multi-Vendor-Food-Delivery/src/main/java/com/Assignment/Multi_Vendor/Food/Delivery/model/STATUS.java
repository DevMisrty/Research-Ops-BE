package com.Assignment.Multi_Vendor.Food.Delivery.model;

import jakarta.persistence.Entity;
import lombok.Getter;
import lombok.Setter;

public enum STATUS {
    APPROVED,
    NOT_APPROVED
}
package com.practice.researchopsproject.entity;

public enum InvitationStatus {
    USE,
    EXPIRE
}

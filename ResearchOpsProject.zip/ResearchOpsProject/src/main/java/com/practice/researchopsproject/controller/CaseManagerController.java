package com.practice.researchopsproject.controller;

import com.practice.researchopsproject.dto.InvitationDto;
import com.practice.researchopsproject.dto.CaseDto;
import com.practice.researchopsproject.dto.request.RegisterCaseManagerRequestDto;
import com.practice.researchopsproject.entity.Case;
import com.practice.researchopsproject.entity.Invitation;
import com.practice.researchopsproject.exception.customException.TokenExpireException;
import com.practice.researchopsproject.services.CaseManagerService;
import com.practice.researchopsproject.services.InvitationService;
import com.practice.researchopsproject.utilities.ApiResponse;
import com.practice.researchopsproject.utilities.JwtUtilities;
import com.practice.researchopsproject.utilities.Messages;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.coyote.BadRequestException;
import org.modelmapper.ModelMapper;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@RequestMapping("/api/cm")
@RequiredArgsConstructor
@CrossOrigin(originPatterns = {"localhost:3000", "localhost:5173"})
public class CaseManagerController {

    private final CaseManagerService service;
    private final InvitationService invitationService;
    private final ModelMapper mapper;
    private final JwtUtilities jwtUtilities;


    // validate the token itself first, if token expired then return error, else return successful response.
    @PostMapping("/register/{token}")
    public ResponseEntity<?> createCaseManager(
            @PathVariable String token,
            @RequestBody RegisterCaseManagerRequestDto requestDto) throws BadRequestException, TokenExpireException {

        service.createCaseManager(token, requestDto);

        return ApiResponse.getResponse(HttpStatus.CREATED, Messages.CASEMANAGER_CREATED, null);
    }

    // accepts the email for each Researcher assigned in the case. as a List.
    @PostMapping("/create/case")
    public ResponseEntity<?> createCase(
            @RequestBody CaseDto requestDto,
            HttpServletRequest request){

        String token = request.getHeader("Authorization");
        token = token.substring(7);
        String email = jwtUtilities.getEmailFromToken(token);
        log.info("Email from Token found is, {}", email);

        Case response = service.createCase(requestDto, email);

        return ApiResponse.getResponse(HttpStatus.OK, Messages.CASE_CREATED, mapper.map(response, CaseDto.class));
    }

//    @GetMapping("/get/rs")
//    public ResponseEntity<?> getListOfActiveResearcher(
//            @RequestParam(required = false, defaultValue = "0") int page,
//            @RequestParam(required = false, defaultValue = "5") int limit,
//            @RequestParam(required = false, defaultValue = "name") String searchBy
//    ){
//        if(page< 0)page =0;
//        if(limit<= 0)limit =5;
//
//        service.getResearchers(page, limit);
//    } 1

    @PutMapping("/edit/case/{id}")
    public ResponseEntity<?> editCase(
            @RequestBody CaseDto caseDto,
            @PathVariable String id,
            HttpServletRequest request ) throws BadRequestException {

        log.info("Edit case started");
        String token = request.getHeader("Authorization");
        token = token.substring(7);

        String email = jwtUtilities.getEmailFromToken(token);

        Case aCase = service.editCase(caseDto, email, id);
        return ApiResponse.getResponse(HttpStatus.FOUND, Messages.CASE_UPDATED, mapper.map(aCase, CaseDto.class) );

    }



}

package com.practice.researchopsproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ResearchOpsProjectApplicationTests {

    @Test
    void contextLoads() {
    }

}

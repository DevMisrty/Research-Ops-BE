package com.practice.thoughtstream.model;


public enum UsersRole {

    ADMIN,
    USERS
}

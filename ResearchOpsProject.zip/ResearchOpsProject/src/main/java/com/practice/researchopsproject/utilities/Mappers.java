package com.practice.researchopsproject.utilities;

import com.practice.researchopsproject.dto.response.CaseManagerResponseDto;
import com.practice.researchopsproject.dto.response.ResearcherResponseDto;
import com.practice.researchopsproject.entity.CaseManagerProfile;
import com.practice.researchopsproject.entity.ResearcherProfile;

public class Mappers {

    public static CaseManagerResponseDto mapCaseManagerToCaseManagerResponseDto(CaseManagerProfile profile){
        return CaseManagerResponseDto.builder()
                .name(profile.getUser().getName())
                .email(profile.getUser().getEmail())
                .isActive(profile.getUser().isActive())
                .assignCases(profile.getAssignCaseId().size())
                .lastLogin(profile.getUser().getLastLogin())
                .build();
    }

    public static ResearcherResponseDto mapResearcherToResearcherResponseDto(ResearcherProfile profile){
        return ResearcherResponseDto.builder()
                .name(profile.getUser().getName())
                .email(profile.getUser().getEmail())
                .assignCases(profile.getAssignCaseIds().size())
                .experience(profile.getExperience())
                .isActive(profile.getUser().isActive())
                .build();
    }

}

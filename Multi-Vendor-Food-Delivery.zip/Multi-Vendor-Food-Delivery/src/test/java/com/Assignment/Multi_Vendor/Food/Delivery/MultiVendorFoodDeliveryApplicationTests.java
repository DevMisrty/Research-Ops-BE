package com.Assignment.Multi_Vendor.Food.Delivery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MultiVendorFoodDeliveryApplicationTests {

	@Test
	void contextLoads() {
	}

}

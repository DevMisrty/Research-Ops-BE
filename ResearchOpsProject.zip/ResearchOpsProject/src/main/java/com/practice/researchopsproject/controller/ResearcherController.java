package com.practice.researchopsproject.controller;

import com.practice.researchopsproject.dto.InvitationDto;
import com.practice.researchopsproject.dto.request.CreateResearcherRequestDto;
import com.practice.researchopsproject.dto.request.RegisterResearcherRequestDto;
import com.practice.researchopsproject.entity.Invitation;
import com.practice.researchopsproject.services.InvitationService;
import com.practice.researchopsproject.services.ResearcherService;
import com.practice.researchopsproject.utilities.ApiResponse;
import com.practice.researchopsproject.utilities.Messages;
import lombok.RequiredArgsConstructor;
import org.apache.coyote.BadRequestException;
import org.modelmapper.ModelMapper;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/rs")
@RequiredArgsConstructor
@CrossOrigin(originPatterns = {"localhost:3000", "localhost:5173"})
public class ResearcherController {

    private final ResearcherService service;
    private final ModelMapper mapper;
    private final InvitationService invitationService;

    @PostMapping("/register/{token}")
    public ResponseEntity<?> createResearcher(
            @PathVariable String token,
            @RequestBody RegisterResearcherRequestDto requestDto) throws BadRequestException {

        service.createResearchProfile(token, requestDto);

        return ApiResponse.getResponse(HttpStatus.CREATED, Messages.RESEARCHER_CREATED, "researcher profile created");
    }

    @GetMapping("/get/{token}")
    public ResponseEntity<?> getInvitationToken(@PathVariable String token) throws BadRequestException {

        Invitation invitation = invitationService.getInvitationFromToken(token);
        InvitationDto response = mapper.map(invitation, InvitationDto.class);

        return ApiResponse.getResponse(HttpStatus.OK, Messages.INVITATION_TOKEN_FETCHED, response);
    }



}

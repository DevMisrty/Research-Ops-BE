package com.learning.expensetrackermdb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExpenseTrackerMDbApplicationTests {

    @Test
    void contextLoads() {
    }

}

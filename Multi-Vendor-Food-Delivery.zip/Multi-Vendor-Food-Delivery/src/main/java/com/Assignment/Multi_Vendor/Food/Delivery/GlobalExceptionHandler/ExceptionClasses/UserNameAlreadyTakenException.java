package com.Assignment.Multi_Vendor.Food.Delivery.GlobalExceptionHandler.ExceptionClasses;

public class UserNameAlreadyTakenException extends Exception{
    public UserNameAlreadyTakenException() {
        super("");
    }
}
